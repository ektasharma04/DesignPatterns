import java.util.Scanner;


public class MainApp {

	public static void main(String args[])
	{
		ListBuilder builder = new ListBuilder();
		System.out.println("Please input a list");
		Scanner src = new Scanner(System.in);
		String input=src.next();
		String a[]=input.split(" ");
		int inpLength=a.length;
		//for(i=0;i<)
		for(String token:a)
		{
			 if (token == "(") builder.buildOpenBracket();
			    else if (token == ")") builder.buildCloseBracket();
			    else if (checkNumber(token)) builder.buildElement(Integer.parseInt(token));
			
		}
		//ListComponent list = builder.getList();
		list.printValue();
		/*read in input list into a string and tokenize it.
		 
		for each token in the input string 
		    if (token == “(“) builder.buildOpenBracket();
		    else if (token == “)“) builder.buildCloseBracket();
		    else if (token == number) builder.buildElement(number);
		ListComponent list = builder.getList();
		list.printValue();*/
	}
	public static boolean checkNumber(String token)
	{
		try
	    {
	        Integer.parseInt(token);
	    }
	    catch(NumberFormatException ex)
	    {
	        return false;
	    }
	    return true;
		
		
	}
}
